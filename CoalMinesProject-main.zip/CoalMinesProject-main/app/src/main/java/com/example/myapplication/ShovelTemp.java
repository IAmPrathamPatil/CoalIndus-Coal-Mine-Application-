package com.example.myapplication;

public class ShovelTemp {

    private String Overburden_Shovel_SIno;
    private String Overburden_Shovel_Shovelno;
    private String Overburden_Shovel_Benchno;
    private String Overburden_Shovel_Solidquantity;
    private String Overburden_Shovel_Rehandalingquantity;
    private String Overburden_Shovel_Totalquantity;

    public ShovelTemp() {
    }


    public ShovelTemp(String overburden_Shovel_SIno, String overburden_Shovel_Shovelno, String overburden_Shovel_Benchno, String overburden_Shovel_Solidquantity, String overburden_Shovel_Rehandalingquantity, String overburden_Shovel_Totalquantity) {
        Overburden_Shovel_SIno = overburden_Shovel_SIno;
        Overburden_Shovel_Shovelno = overburden_Shovel_Shovelno;
        Overburden_Shovel_Benchno = overburden_Shovel_Benchno;
        Overburden_Shovel_Solidquantity = overburden_Shovel_Solidquantity;
        Overburden_Shovel_Rehandalingquantity = overburden_Shovel_Rehandalingquantity;
        Overburden_Shovel_Totalquantity = overburden_Shovel_Totalquantity;
    }

    public String getOverburden_Shovel_SIno() {
        return Overburden_Shovel_SIno;
    }

    public void setOverburden_Shovel_SIno(String overburden_Shovel_SIno) {
        Overburden_Shovel_SIno = overburden_Shovel_SIno;
    }

    public String getOverburden_Shovel_Shovelno() {
        return Overburden_Shovel_Shovelno;
    }

    public void setOverburden_Shovel_Shovelno(String overburden_Shovel_Shovelno) {
        Overburden_Shovel_Shovelno = overburden_Shovel_Shovelno;
    }

    public String getOverburden_Shovel_Benchno() {
        return Overburden_Shovel_Benchno;
    }

    public void setOverburden_Shovel_Benchno(String overburden_Shovel_Benchno) {
        Overburden_Shovel_Benchno = overburden_Shovel_Benchno;
    }

    public String getOverburden_Shovel_Solidquantity() {
        return Overburden_Shovel_Solidquantity;
    }

    public void setOverburden_Shovel_Solidquantity(String overburden_Shovel_Solidquantity) {
        Overburden_Shovel_Solidquantity = overburden_Shovel_Solidquantity;
    }

    public String getOverburden_Shovel_Rehandalingquantity() {
        return Overburden_Shovel_Rehandalingquantity;
    }

    public void setOverburden_Shovel_Rehandalingquantity(String overburden_Shovel_Rehandalingquantity) {
        Overburden_Shovel_Rehandalingquantity = overburden_Shovel_Rehandalingquantity;
    }

    public String getOverburden_Shovel_Totalquantity() {
        return Overburden_Shovel_Totalquantity;
    }

    public void setOverburden_Shovel_Totalquantity(String overburden_Shovel_Totalquantity) {
        Overburden_Shovel_Totalquantity = overburden_Shovel_Totalquantity;
    }
}


