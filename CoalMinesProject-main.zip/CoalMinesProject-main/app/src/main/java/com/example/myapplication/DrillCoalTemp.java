package com.example.myapplication;

public class DrillCoalTemp {
    private String Coal_Drill_Serialno;
    private String Coal_Drill_Drillno;
    private String Coal_Drill_Benchno;
    private String Coal_Drill_Noofshotholesdrilled;
    private String Coal_Drill_Drillingmeter;
    private String Coal_Drill_Total;

    public DrillCoalTemp() {
    }

    public DrillCoalTemp(String coal_Drill_Serialno, String coal_Drill_Drillno, String coal_Drill_Benchno, String coal_Drill_Noofshotholesdrilled, String coal_Drill_Drillingmeter, String coal_Drill_Total) {
        Coal_Drill_Serialno = coal_Drill_Serialno;
        Coal_Drill_Drillno = coal_Drill_Drillno;
        Coal_Drill_Benchno = coal_Drill_Benchno;
        Coal_Drill_Noofshotholesdrilled = coal_Drill_Noofshotholesdrilled;
        Coal_Drill_Drillingmeter = coal_Drill_Drillingmeter;
        Coal_Drill_Total = coal_Drill_Total;
    }

    public String getCoal_Drill_Serialno() {
        return Coal_Drill_Serialno;
    }

    public void setCoal_Drill_Serialno(String coal_Drill_Serialno) {
        Coal_Drill_Serialno = coal_Drill_Serialno;
    }

    public String getCoal_Drill_Drillno() {
        return Coal_Drill_Drillno;
    }

    public void setCoal_Drill_Drillno(String coal_Drill_Drillno) {
        Coal_Drill_Drillno = coal_Drill_Drillno;
    }

    public String getCoal_Drill_Benchno() {
        return Coal_Drill_Benchno;
    }

    public void setCoal_Drill_Benchno(String coal_Drill_Benchno) {
        Coal_Drill_Benchno = coal_Drill_Benchno;
    }

    public String getCoal_Drill_Noofshotholesdrilled() {
        return Coal_Drill_Noofshotholesdrilled;
    }

    public void setCoal_Drill_Noofshotholesdrilled(String coal_Drill_Noofshotholesdrilled) {
        Coal_Drill_Noofshotholesdrilled = coal_Drill_Noofshotholesdrilled;
    }

    public String getCoal_Drill_Drillingmeter() {
        return Coal_Drill_Drillingmeter;
    }

    public void setCoal_Drill_Drillingmeter(String coal_Drill_Drillingmeter) {
        Coal_Drill_Drillingmeter = coal_Drill_Drillingmeter;
    }

    public String getCoal_Drill_Total() {
        return Coal_Drill_Total;
    }

    public void setCoal_Drill_Total(String coal_Drill_Total) {
        Coal_Drill_Total = coal_Drill_Total;
    }
}
