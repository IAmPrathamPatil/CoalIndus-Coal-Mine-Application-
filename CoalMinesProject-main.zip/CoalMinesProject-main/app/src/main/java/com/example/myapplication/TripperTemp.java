package com.example.myapplication;

public class TripperTemp {

    private String Overburden_Tripper_SIno;
    private String Overburden_Tripper_Tripperno;
    private String Overburden_Tripper_Dumperfac;
    private String Overburden_Tripper_Benchno;
    private String Overburden_Tripper_Tripsno;
    private String Overburden_Tripper_Soilquantity;
    private String Overburden_Tripper_Rehanquantity;
    private String Overburden_Tripper_Totalquantity;

    public TripperTemp() {
    }

    public TripperTemp(String overburden_Tripper_SIno, String overburden_Tripper_Tripperno, String overburden_Tripper_Dumperfac, String overburden_Tripper_Benchno, String overburden_Tripper_Tripsno, String overburden_Tripper_Soilquantity, String overburden_Tripper_Rehanquantity, String overburden_Tripper_Totalquantity) {
        Overburden_Tripper_SIno = overburden_Tripper_SIno;
        Overburden_Tripper_Tripperno = overburden_Tripper_Tripperno;
        Overburden_Tripper_Dumperfac = overburden_Tripper_Dumperfac;
        Overburden_Tripper_Benchno = overburden_Tripper_Benchno;
        Overburden_Tripper_Tripsno = overburden_Tripper_Tripsno;
        Overburden_Tripper_Soilquantity = overburden_Tripper_Soilquantity;
        Overburden_Tripper_Rehanquantity = overburden_Tripper_Rehanquantity;
        Overburden_Tripper_Totalquantity = overburden_Tripper_Totalquantity;
    }

    public String getOverburden_Tripper_SIno() {
        return Overburden_Tripper_SIno;
    }

    public void setOverburden_Tripper_SIno(String overburden_Tripper_SIno) {
        Overburden_Tripper_SIno = overburden_Tripper_SIno;
    }

    public String getOverburden_Tripper_Tripperno() {
        return Overburden_Tripper_Tripperno;
    }

    public void setOverburden_Tripper_Tripperno(String overburden_Tripper_Tripperno) {
        Overburden_Tripper_Tripperno = overburden_Tripper_Tripperno;
    }

    public String getOverburden_Tripper_Dumperfac() {
        return Overburden_Tripper_Dumperfac;
    }

    public void setOverburden_Tripper_Dumperfac(String overburden_Tripper_Dumperfac) {
        Overburden_Tripper_Dumperfac = overburden_Tripper_Dumperfac;
    }

    public String getOverburden_Tripper_Benchno() {
        return Overburden_Tripper_Benchno;
    }

    public void setOverburden_Tripper_Benchno(String overburden_Tripper_Benchno) {
        Overburden_Tripper_Benchno = overburden_Tripper_Benchno;
    }

    public String getOverburden_Tripper_Tripsno() {
        return Overburden_Tripper_Tripsno;
    }

    public void setOverburden_Tripper_Tripsno(String overburden_Tripper_Tripsno) {
        Overburden_Tripper_Tripsno = overburden_Tripper_Tripsno;
    }

    public String getOverburden_Tripper_Soilquantity() {
        return Overburden_Tripper_Soilquantity;
    }

    public void setOverburden_Tripper_Soilquantity(String overburden_Tripper_Soilquantity) {
        Overburden_Tripper_Soilquantity = overburden_Tripper_Soilquantity;
    }

    public String getOverburden_Tripper_Rehanquantity() {
        return Overburden_Tripper_Rehanquantity;
    }

    public void setOverburden_Tripper_Rehanquantity(String overburden_Tripper_Rehanquantity) {
        Overburden_Tripper_Rehanquantity = overburden_Tripper_Rehanquantity;
    }

    public String getOverburden_Tripper_Totalquantity() {
        return Overburden_Tripper_Totalquantity;
    }

    public void setOverburden_Tripper_Totalquantity(String overburden_Tripper_Totalquantity) {
        Overburden_Tripper_Totalquantity = overburden_Tripper_Totalquantity;
    }
}
