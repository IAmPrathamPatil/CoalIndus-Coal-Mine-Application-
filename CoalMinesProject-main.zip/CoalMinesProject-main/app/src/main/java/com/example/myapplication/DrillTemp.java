package com.example.myapplication;

public class DrillTemp {
    private String Overburden_Drill_Serialno;
    private String Overburden_Drill_Drillno;
    private String Overburden_Drill_Benchno;
    private String Overburden_Drill_Noofshotholesdrilled;
    private String Overburden_Drill_Drillingmeter;
    private String Overburden_Drill_Total;

    public DrillTemp() {
    }

    public DrillTemp(String overburden_Drill_Serialno, String overburden_Drill_Drillno, String overburden_Drill_Benchno, String overburden_Drill_Noofshotholesdrilled, String overburden_Drill_Drillingmeter, String overburden_Drill_Total) {
        Overburden_Drill_Serialno = overburden_Drill_Serialno;
        Overburden_Drill_Drillno = overburden_Drill_Drillno;
        Overburden_Drill_Benchno = overburden_Drill_Benchno;
        Overburden_Drill_Noofshotholesdrilled = overburden_Drill_Noofshotholesdrilled;
        Overburden_Drill_Drillingmeter = overburden_Drill_Drillingmeter;
        Overburden_Drill_Total = overburden_Drill_Total;
    }

    public String getOverburden_Drill_Serialno() {
        return Overburden_Drill_Serialno;
    }

    public void setOverburden_Drill_Serialno(String overburden_Drill_Serialno) {
        Overburden_Drill_Serialno = overburden_Drill_Serialno;
    }

    public String getOverburden_Drill_Drillno() {
        return Overburden_Drill_Drillno;
    }

    public void setOverburden_Drill_Drillno(String overburden_Drill_Drillno) {
        Overburden_Drill_Drillno = overburden_Drill_Drillno;
    }

    public String getOverburden_Drill_Benchno() {
        return Overburden_Drill_Benchno;
    }

    public void setOverburden_Drill_Benchno(String overburden_Drill_Benchno) {
        Overburden_Drill_Benchno = overburden_Drill_Benchno;
    }

    public String getOverburden_Drill_Noofshotholesdrilled() {
        return Overburden_Drill_Noofshotholesdrilled;
    }

    public void setOverburden_Drill_Noofshotholesdrilled(String overburden_Drill_Noofshotholesdrilled) {
        Overburden_Drill_Noofshotholesdrilled = overburden_Drill_Noofshotholesdrilled;
    }

    public String getOverburden_Drill_Drillingmeter() {
        return Overburden_Drill_Drillingmeter;
    }

    public void setOverburden_Drill_Drillingmeter(String overburden_Drill_Drillingmeter) {
        Overburden_Drill_Drillingmeter = overburden_Drill_Drillingmeter;
    }

    public String getOverburden_Drill_Total() {
        return Overburden_Drill_Total;
    }

    public void setOverburden_Drill_Total(String overburden_Drill_Total) {
        Overburden_Drill_Total = overburden_Drill_Total;
    }
}
