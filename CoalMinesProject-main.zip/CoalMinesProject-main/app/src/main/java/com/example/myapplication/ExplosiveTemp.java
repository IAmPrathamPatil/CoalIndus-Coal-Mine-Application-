package com.example.myapplication;

public class ExplosiveTemp {
    private String Overburden_Explosives_SIno;
    private String Overburden_Explosives_Benchno;
    private String Overburden_Explosives_Noholescharged;
    private String Overburden_Explosives_NoholesBlasetedd;
    private String Overburden_Explosives_Explosivescharged;
    private String Overburden_Explosives_Explosiveblasted;

    public ExplosiveTemp() {
    }

    public ExplosiveTemp(String overburden_Explosives_SIno, String overburden_Explosives_Benchno, String overburden_Explosives_Noholescharged, String overburden_Explosives_NoholesBlasetedd, String overburden_Explosives_Explosivescharged, String overburden_Explosives_Explosiveblasted) {
        Overburden_Explosives_SIno = overburden_Explosives_SIno;
        Overburden_Explosives_Benchno = overburden_Explosives_Benchno;
        Overburden_Explosives_Noholescharged = overburden_Explosives_Noholescharged;
        Overburden_Explosives_NoholesBlasetedd = overburden_Explosives_NoholesBlasetedd;
        Overburden_Explosives_Explosivescharged = overburden_Explosives_Explosivescharged;
        Overburden_Explosives_Explosiveblasted = overburden_Explosives_Explosiveblasted;
    }

    public String getOverburden_Explosives_SIno() {
        return Overburden_Explosives_SIno;
    }

    public void setOverburden_Explosives_SIno(String overburden_Explosives_SIno) {
        Overburden_Explosives_SIno = overburden_Explosives_SIno;
    }

    public String getOverburden_Explosives_Benchno() {
        return Overburden_Explosives_Benchno;
    }

    public void setOverburden_Explosives_Benchno(String overburden_Explosives_Benchno) {
        Overburden_Explosives_Benchno = overburden_Explosives_Benchno;
    }

    public String getOverburden_Explosives_Noholescharged() {
        return Overburden_Explosives_Noholescharged;
    }

    public void setOverburden_Explosives_Noholescharged(String overburden_Explosives_Noholescharged) {
        Overburden_Explosives_Noholescharged = overburden_Explosives_Noholescharged;
    }

    public String getOverburden_Explosives_NoholesBlasetedd() {
        return Overburden_Explosives_NoholesBlasetedd;
    }

    public void setOverburden_Explosives_NoholesBlasetedd(String overburden_Explosives_NoholesBlasetedd) {
        Overburden_Explosives_NoholesBlasetedd = overburden_Explosives_NoholesBlasetedd;
    }

    public String getOverburden_Explosives_Explosivescharged() {
        return Overburden_Explosives_Explosivescharged;
    }

    public void setOverburden_Explosives_Explosivescharged(String overburden_Explosives_Explosivescharged) {
        Overburden_Explosives_Explosivescharged = overburden_Explosives_Explosivescharged;
    }

    public String getOverburden_Explosives_Explosiveblasted() {
        return Overburden_Explosives_Explosiveblasted;
    }

    public void setOverburden_Explosives_Explosiveblasted(String overburden_Explosives_Explosiveblasted) {
        Overburden_Explosives_Explosiveblasted = overburden_Explosives_Explosiveblasted;
    }
}
