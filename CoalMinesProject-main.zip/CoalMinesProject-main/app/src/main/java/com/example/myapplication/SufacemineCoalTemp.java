package com.example.myapplication;

public class SufacemineCoalTemp {
    private String Coal_Surfaceminer_Serialno;
    private String Coal_Surfaceminer_Minerno;
    private String Coal_Surfaceminer_Benchno;
    private String Coal_Surfaceminer_Coalquantity;

    public SufacemineCoalTemp() {
    }

    public SufacemineCoalTemp(String coal_Surfaceminer_Serialno, String coal_Surfaceminer_Minerno, String coal_Surfaceminer_Benchno, String coal_Surfaceminer_Coalquantity) {
        Coal_Surfaceminer_Serialno = coal_Surfaceminer_Serialno;
        Coal_Surfaceminer_Minerno = coal_Surfaceminer_Minerno;
        Coal_Surfaceminer_Benchno = coal_Surfaceminer_Benchno;
        Coal_Surfaceminer_Coalquantity = coal_Surfaceminer_Coalquantity;
    }

    public String getCoal_Surfaceminer_Serialno() {
        return Coal_Surfaceminer_Serialno;
    }

    public void setCoal_Surfaceminer_Serialno(String coal_Surfaceminer_Serialno) {
        Coal_Surfaceminer_Serialno = coal_Surfaceminer_Serialno;
    }

    public String getCoal_Surfaceminer_Minerno() {
        return Coal_Surfaceminer_Minerno;
    }

    public void setCoal_Surfaceminer_Minerno(String coal_Surfaceminer_Minerno) {
        Coal_Surfaceminer_Minerno = coal_Surfaceminer_Minerno;
    }

    public String getCoal_Surfaceminer_Benchno() {
        return Coal_Surfaceminer_Benchno;
    }

    public void setCoal_Surfaceminer_Benchno(String coal_Surfaceminer_Benchno) {
        Coal_Surfaceminer_Benchno = coal_Surfaceminer_Benchno;
    }

    public String getCoal_Surfaceminer_Coalquantity() {
        return Coal_Surfaceminer_Coalquantity;
    }

    public void setCoal_Surfaceminer_Coalquantity(String coal_Surfaceminer_Coalquantity) {
        Coal_Surfaceminer_Coalquantity = coal_Surfaceminer_Coalquantity;
    }
}
