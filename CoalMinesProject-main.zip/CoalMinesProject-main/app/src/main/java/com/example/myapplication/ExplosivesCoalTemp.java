package com.example.myapplication;

public class ExplosivesCoalTemp {
    private String Coal_Explosives_SIno;
    private String Coal_Explosives_Benchno;
    private String Coal_Explosives_Noholescharged;
    private String Coal_Explosives_NoholesBlasetedd;
    private String Coal_Explosives_Explosivescharged;
    private String Coal_Explosives_Explosiveblasted;

    public ExplosivesCoalTemp() {
    }

    public ExplosivesCoalTemp(String coal_Explosives_SIno, String coal_Explosives_Benchno, String coal_Explosives_Noholescharged, String coal_Explosives_NoholesBlasetedd, String coal_Explosives_Explosivescharged, String coal_Explosives_Explosiveblasted) {
        Coal_Explosives_SIno = coal_Explosives_SIno;
        Coal_Explosives_Benchno = coal_Explosives_Benchno;
        Coal_Explosives_Noholescharged = coal_Explosives_Noholescharged;
        Coal_Explosives_NoholesBlasetedd = coal_Explosives_NoholesBlasetedd;
        Coal_Explosives_Explosivescharged = coal_Explosives_Explosivescharged;
        Coal_Explosives_Explosiveblasted = coal_Explosives_Explosiveblasted;
    }

    public String getCoal_Explosives_SIno() {
        return Coal_Explosives_SIno;
    }

    public void setCoal_Explosives_SIno(String coal_Explosives_SIno) {
        Coal_Explosives_SIno = coal_Explosives_SIno;
    }

    public String getCoal_Explosives_Benchno() {
        return Coal_Explosives_Benchno;
    }

    public void setCoal_Explosives_Benchno(String coal_Explosives_Benchno) {
        Coal_Explosives_Benchno = coal_Explosives_Benchno;
    }

    public String getCoal_Explosives_Noholescharged() {
        return Coal_Explosives_Noholescharged;
    }

    public void setCoal_Explosives_Noholescharged(String coal_Explosives_Noholescharged) {
        Coal_Explosives_Noholescharged = coal_Explosives_Noholescharged;
    }

    public String getCoal_Explosives_NoholesBlasetedd() {
        return Coal_Explosives_NoholesBlasetedd;
    }

    public void setCoal_Explosives_NoholesBlasetedd(String coal_Explosives_NoholesBlasetedd) {
        Coal_Explosives_NoholesBlasetedd = coal_Explosives_NoholesBlasetedd;
    }

    public String getCoal_Explosives_Explosivescharged() {
        return Coal_Explosives_Explosivescharged;
    }

    public void setCoal_Explosives_Explosivescharged(String coal_Explosives_Explosivescharged) {
        Coal_Explosives_Explosivescharged = coal_Explosives_Explosivescharged;
    }

    public String getCoal_Explosives_Explosiveblasted() {
        return Coal_Explosives_Explosiveblasted;
    }

    public void setCoal_Explosives_Explosiveblasted(String coal_Explosives_Explosiveblasted) {
        Coal_Explosives_Explosiveblasted = coal_Explosives_Explosiveblasted;
    }
}
