package com.example.myapplication;

public class TripperCoalTemp {

    private String Coal_Tripper_Serialno;
    private String Coal_Tripper_Tripperno;
    private String Coal_Tripper_Benchno;
    private String Coal_Tripper_Dumperfactor;
    private String Coal_Tripper_Tripsnowithoutwieghts;
    private String Coal_Tripper_CoalQuantitywithoutweights;
    private String Coal_Tripper_Tripsnowithweights;
    private String Coal_Tripper_CoalQuantitywithweights;

    public TripperCoalTemp() {
    }

    public TripperCoalTemp(String coal_Tripper_Serialno, String coal_Tripper_Tripperno, String coal_Tripper_Benchno, String coal_Tripper_Dumperfactor, String coal_Tripper_Tripsnowithoutwieghts, String coal_Tripper_CoalQuantitywithoutweights, String coal_Tripper_Tripsnowithweights, String coal_Tripper_CoalQuantitywithweights) {
        Coal_Tripper_Serialno = coal_Tripper_Serialno;
        Coal_Tripper_Tripperno = coal_Tripper_Tripperno;
        Coal_Tripper_Benchno = coal_Tripper_Benchno;
        Coal_Tripper_Dumperfactor = coal_Tripper_Dumperfactor;
        Coal_Tripper_Tripsnowithoutwieghts = coal_Tripper_Tripsnowithoutwieghts;
        Coal_Tripper_CoalQuantitywithoutweights = coal_Tripper_CoalQuantitywithoutweights;
        Coal_Tripper_Tripsnowithweights = coal_Tripper_Tripsnowithweights;
        Coal_Tripper_CoalQuantitywithweights = coal_Tripper_CoalQuantitywithweights;
    }

    public String getCoal_Tripper_Serialno() {
        return Coal_Tripper_Serialno;
    }

    public void setCoal_Tripper_Serialno(String coal_Tripper_Serialno) {
        Coal_Tripper_Serialno = coal_Tripper_Serialno;
    }

    public String getCoal_Tripper_Tripperno() {
        return Coal_Tripper_Tripperno;
    }

    public void setCoal_Tripper_Tripperno(String coal_Tripper_Tripperno) {
        Coal_Tripper_Tripperno = coal_Tripper_Tripperno;
    }

    public String getCoal_Tripper_Benchno() {
        return Coal_Tripper_Benchno;
    }

    public void setCoal_Tripper_Benchno(String coal_Tripper_Benchno) {
        Coal_Tripper_Benchno = coal_Tripper_Benchno;
    }

    public String getCoal_Tripper_Dumperfactor() {
        return Coal_Tripper_Dumperfactor;
    }

    public void setCoal_Tripper_Dumperfactor(String coal_Tripper_Dumperfactor) {
        Coal_Tripper_Dumperfactor = coal_Tripper_Dumperfactor;
    }

    public String getCoal_Tripper_Tripsnowithoutwieghts() {
        return Coal_Tripper_Tripsnowithoutwieghts;
    }

    public void setCoal_Tripper_Tripsnowithoutwieghts(String coal_Tripper_Tripsnowithoutwieghts) {
        Coal_Tripper_Tripsnowithoutwieghts = coal_Tripper_Tripsnowithoutwieghts;
    }

    public String getCoal_Tripper_CoalQuantitywithoutweights() {
        return Coal_Tripper_CoalQuantitywithoutweights;
    }

    public void setCoal_Tripper_CoalQuantitywithoutweights(String coal_Tripper_CoalQuantitywithoutweights) {
        Coal_Tripper_CoalQuantitywithoutweights = coal_Tripper_CoalQuantitywithoutweights;
    }

    public String getCoal_Tripper_Tripsnowithweights() {
        return Coal_Tripper_Tripsnowithweights;
    }

    public void setCoal_Tripper_Tripsnowithweights(String coal_Tripper_Tripsnowithweights) {
        Coal_Tripper_Tripsnowithweights = coal_Tripper_Tripsnowithweights;
    }

    public String getCoal_Tripper_CoalQuantitywithweights() {
        return Coal_Tripper_CoalQuantitywithweights;
    }

    public void setCoal_Tripper_CoalQuantitywithweights(String coal_Tripper_CoalQuantitywithweights) {
        Coal_Tripper_CoalQuantitywithweights = coal_Tripper_CoalQuantitywithweights;
    }
}
