package com.example.myapplication;

public class ShovelCoalTemp {

    private String Coal_Shovel_Serialno;
    private String Coal_Shovel_Shovelno;
    private String Coal_Shovel_Benchno;
    private String Coal_Shovel_Coalquantity;

    public ShovelCoalTemp() {
    }

    public ShovelCoalTemp(String coal_Shovel_Serialno, String coal_Shovel_Shovelno, String coal_Shovel_Benchno, String coal_Shovel_Coalquantity) {
        Coal_Shovel_Serialno = coal_Shovel_Serialno;
        Coal_Shovel_Shovelno = coal_Shovel_Shovelno;
        Coal_Shovel_Benchno = coal_Shovel_Benchno;
        Coal_Shovel_Coalquantity = coal_Shovel_Coalquantity;
    }

    public String getCoal_Shovel_Serialno() {
        return Coal_Shovel_Serialno;
    }

    public void setCoal_Shovel_Serialno(String coal_Shovel_Serialno) {
        Coal_Shovel_Serialno = coal_Shovel_Serialno;
    }

    public String getCoal_Shovel_Shovelno() {
        return Coal_Shovel_Shovelno;
    }

    public void setCoal_Shovel_Shovelno(String coal_Shovel_Shovelno) {
        Coal_Shovel_Shovelno = coal_Shovel_Shovelno;
    }

    public String getCoal_Shovel_Benchno() {
        return Coal_Shovel_Benchno;
    }

    public void setCoal_Shovel_Benchno(String coal_Shovel_Benchno) {
        Coal_Shovel_Benchno = coal_Shovel_Benchno;
    }

    public String getCoal_Shovel_Coalquantity() {
        return Coal_Shovel_Coalquantity;
    }

    public void setCoal_Shovel_Coalquantity(String coal_Shovel_Coalquantity) {
        Coal_Shovel_Coalquantity = coal_Shovel_Coalquantity;
    }
}
